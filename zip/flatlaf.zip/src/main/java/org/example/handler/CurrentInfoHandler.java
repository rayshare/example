package org.example.handler;

import org.example.ButtonEvent;
import org.example.SubFrame;

import javax.swing.*;
import java.awt.*;

public class CurrentInfoHandler extends BaseEventHandler {
    @Override
    public String handle(ButtonEvent buttonEvent) {
        SubFrame frame = new SubFrame(buttonEvent.getMainFrame(), "SubFrame", true);
        frame.setPreferredSize(new Dimension(830, 440));
        frame.pack();
        Point location = (Point) buttonEvent.getMainFrame().getLocation().clone();
        location.setLocation(location.getX(), location.getY() + 100);
        frame.setLocation(location);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);
        return null;
    }
}
