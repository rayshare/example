package org.example.handler;

import org.example.frame.OnlineFrame;

import javax.swing.*;
import java.awt.*;

public class OnlineFetchHandler extends BaseEventHandler {
    @Override
    public String handle(ButtonEvent buttonEvent) {
        OnlineFrame frame = new OnlineFrame(buttonEvent.getMainFrame(), "2024", true);
        frame.setPreferredSize(new Dimension(830, 440));
        frame.pack();
        Point location = (Point) buttonEvent.getMainFrame().getLocation().clone();
        location.setLocation(location.getX() + 100, location.getY() + 100);
        frame.setLocation(location);
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setVisible(true);
        frame.setResizable(false);
        return null;
    }
}
