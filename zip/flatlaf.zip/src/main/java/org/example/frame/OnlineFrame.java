package org.example.frame;

import com.formdev.flatlaf.FlatDarculaLaf;
import org.example.util.GridUtil;
import org.jdesktop.swingx.JXCollapsiblePane;

import javax.swing.*;
import java.awt.*;

public class OnlineFrame extends JDialog {

    static {
        FlatDarculaLaf.setup();
    }

    public OnlineFrame(MainFrame owner, String title, boolean modal) {
        //设置模态框
        super(owner, title, modal);
        setTitle("Online");
        setLayout(new BorderLayout());
        // 创建组件
        JPanel panel = new JPanel();
        JScrollPane jScrollPane = new JScrollPane(panel);
        jScrollPane.setBorder(BorderFactory.createTitledBorder(title));
        jScrollPane.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        jScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        JScrollBar verticalScrollBar = jScrollPane.getVerticalScrollBar();
        verticalScrollBar.setUnitIncrement(20);  // 每次滚动 20 像素

        panel.setLayout(new GridBagLayout());
        for (int i = 0; i < 100; i++) {
            JPanel cp1 = createCollapsPanel("text" + i, "button" + i);
            if (i == 99) {
                panel.add(cp1, GridUtil.floorTopByRow(i, false));
            } else {
                panel.add(cp1, GridUtil.floorTopByRow(i, true));
            }
        }
        add(jScrollPane, BorderLayout.CENTER);
        add(new JPanel(), BorderLayout.WEST);
        add(new JPanel(), BorderLayout.EAST);
    }

    /**
     * 创建折叠面板
     *
     * @param text       折叠内容
     * @param buttonText 折叠按钮文字
     * @return
     */
    private JPanel createCollapsPanel(String text, String buttonText) {
        JXCollapsiblePane cp = new JXCollapsiblePane();
        cp.setLayout(new GridLayout(4, 8, 5, 5));
        cp.setAnimated(false);
        cp.setCollapsed(true);
        for (int i = 0; i < 30; i++) {
            cp.add(new JTextField(text));
        }

        JPanel jPanel = new JPanel(new GridBagLayout());
        JButton button = new JButton(cp.getActionMap().get(JXCollapsiblePane.TOGGLE_ACTION));
        button.setBorderPainted(false);
        button.setText(buttonText);
        jPanel.add(button, GridUtil.floorTopByRow(0, false));
        jPanel.add(cp, GridUtil.floorTopByRow(1, true));
        return jPanel;
    }
}
