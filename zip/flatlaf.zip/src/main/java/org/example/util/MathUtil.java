package org.example.util;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.math3.util.ArithmeticUtils;
import org.example.handler.ButtonEvent;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;

public class MathUtil {
    private static final int scale = 1000;

    public static String average(ButtonEvent buttonEvent) {
        Double[] values = buttonEvent.getMainFrame().getTextFields().stream()
                .filter(e -> !Objects.equals(e.getForeground(), Color.gray))
                .map(JTextField::getText)
                .filter(StringUtils::isNotBlank)
                .map(Double::parseDouble)
                .toArray(Double[]::new);

        List<Integer> integers = middleValue(values);
        if (CollectionUtils.isEmpty(integers)) {
            return null;
        }
        int sum = integers.stream().mapToInt(e -> e).sum();
        List<String> list1 = integers.stream().map(String::valueOf).toList();
        List<Double> avg = new ArrayList<>(integers.size());
        for (int i = 0; i < integers.size(); i++) {
            Integer n1 = integers.get(i);
            Double d1 = values[i];
            avg.add(n1 * d1 / sum);
        }
        List<String> list2 = avg.stream().map(e -> String.format("%.2f", e)).toList();
        return list1 + "\n" + list2;
    }

    public static List<Integer> middleValue(Double... v) {
        if (v.length == 0) {
            return Collections.emptyList();
        }
        List<Long> middle = new ArrayList<>(v.length);
        double product = 1;
        for (Double aDouble : v) {
            if (aDouble <= 0.0) {
                throw new IllegalArgumentException("Input <=0");
            }
            product *= aDouble;
        }
        for (Double aDouble : v) {
            long n = Math.round(product / aDouble * scale);
            int mod = (int) (n % 10);
            if (mod % 2 != 0) {
                if (mod >= 5) {
                    n--;
                } else {
                    n++;
                }
            }
            middle.add(n);
        }
        Long gcd = gcd(middle);
        if (gcd == null) {
            return null;
        }
        List<Integer> ret = new ArrayList<>(v.length);
        for (Long l : middle) {
            int n = (int) (l / gcd);
            ret.add(n);
        }
        return ret;
    }

    private static Long gcd(List<Long> numbers) {
        if (CollectionUtils.isEmpty(numbers)) {
            return null;
        }
        long gcd = numbers.get(0);
        for (int i = 1; i < numbers.size(); i++) {
            gcd = ArithmeticUtils.gcd(gcd, numbers.get(i));
        }
        return gcd;
    }

}
