package org.example;

import com.formdev.flatlaf.FlatDarculaLaf;

import javax.swing.*;
import java.awt.*;

public class SubFrame extends JDialog {

    static {
        FlatDarculaLaf.setup();
    }

    public SubFrame(MainFrame owner, String title, boolean modal) {
        super(owner, title, modal);
        setTitle("SubFrame");
        setLayout(new BorderLayout());
        // 创建组件
        JPanel panel = new JPanel();
        panel.setLayout(new GridLayout(3, 8, 10, 5));
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        panel.add(new JTextField());
        add(panel, BorderLayout.NORTH);
        add(new JPanel(), BorderLayout.WEST);
        add(new JPanel(), BorderLayout.EAST);
    }

}
